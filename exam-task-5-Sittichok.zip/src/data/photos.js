const photos= [
    {
      id: '68a74c6c-dfc3-11ec-9d64-0242ac120002',
      url: 'DSC_3458_1.jpg',
      title: 'sleeping cat',
      feature: false
    },
    {
      id: '51786293-0686-41d6-ba20-85b0fbebc198',
      url: 'DSC_6904.jpg',
      title: 'country road',
      feature: true
    },
    {
      id: '74934a52-37ee-4e13-a0f7-ace2bc849733',
      url: 'DSC_7084-Pano-2-Edit.jpg',
      title: 'The light',
      feature: false
    },
    {
      id: 'c12faf93-f126-47da-af0c-142784d1bcb1',
      url: 'DSC_9736.jpg',
      title: 'The light of the city',
      feature: false
    },
    {
      id: '1694852b-f7d5-4d58-84af-2d513fac96dc',
      url: 'DSD_3210.jpg',
      title: 'Manhattan Bridge',
      feature: true
    },
    {
      id: 'd04dfea9-bb58-4340-a8fe-3b457f2be1fd',
      url: 'DSD_3567-2.jpg',
      title: 'DSD_3567-2',
      feature: true
    },
    {
      id: '63dd955f-b5eb-4e5a-ab1b-f23c84e632b3',
      url: 'DSD_5622.jpg',
      title: 'DC street',
      feature: true
    },
    {
      id: '99d93e3b-01b0-4ed0-a6ec-77d80ecb712d',
      url: 'STG_6802_1.jpg',
      title: 'darkness',
      feature: true
    },
    {
      id: 'fd6556e9-cf0e-47ed-923c-807e12d4323c',
      url: 'STG_8162_1.jpg',
      title: 'floating market',
      feature: false
    }
  ]

export default photos